</div>
<footer style="background:#007bff;color:white;padding:10px;text-align:center;">
    <small>Praktikum 11 - Pemrograman Web</small>
</footer>
</body>
</html>
