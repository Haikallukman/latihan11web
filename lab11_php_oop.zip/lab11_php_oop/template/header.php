<!DOCTYPE html>
<html>
<head>
    <title>Modular PHP OOP</title>
    <style>
        body { font-family: Arial; margin:0; padding:0; }
        .header { background:#007bff; color:#fff; padding:15px; }
        .content { margin-left:200px; padding:20px; }
        .sidebar { width:200px; background:#f5f5f5; height:100vh; position:fixed; }
        .sidebar a { display:block; padding:10px; color:#333; text-decoration:none; }
        .sidebar a:hover { background:#ddd; }
    </style>
</head>
<body>
<div class="header">
    <h2>Framework Modular – Praktikum 11</h2>
</div>
