<?php
$db = new Database();
$id = $_GET['id'];

$data = $db->get("artikel", "id=$id");

$form = new Form("/lab11_php_oop/artikel/ubah?id=$id", "Update");

if ($_POST) {
    $db->update("artikel", [
        "judul" => $_POST['judul'],
        "isi" => $_POST['isi']
    ], "id=$id");

    echo "<script>alert('Berhasil diperbarui');location.href='/lab11_php_oop/artikel/index';</script>";
}
?>

<h2>Ubah Artikel</h2>

<?php
$form->addField("judul", "Judul", "text");
$form->addField("isi", "Isi Artikel", "textarea");
$form->displayForm();
?>
