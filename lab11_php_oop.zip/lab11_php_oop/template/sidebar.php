<div class="sidebar">
    <a href="/lab11_php_oop/home/index">Home</a>
    <a href="/lab11_php_oop/artikel/index">Artikel</a>
    <a href="/lab11_php_oop/artikel/tambah">Tambah Artikel</a>
</div>
<div class="content">
